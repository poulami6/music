<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Users Tracks', 'miraculous'),
        'description'   => __('Users Tracks', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-music',
        'popup_size'    => 'small', 
    )
);
?>
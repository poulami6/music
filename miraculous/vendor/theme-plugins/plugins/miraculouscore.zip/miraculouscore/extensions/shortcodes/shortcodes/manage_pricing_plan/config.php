<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Manage Pricing Plan', 'miraculous'),
        'description'   => __('Manage Pricing Plan', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-university',
        'popup_size'    => 'small', 
    )
);
?>
<?php if (!defined('FW')) die('Forbidden');
$category = '';
if(function_exists('get_custom_type_category')):
    $category = get_custom_type_category('artist-type');
endif;

$options = array(
    'artists_label'   => array(
        'label'   => __('Label', 'miraculous'),
        'help'    => __('help', 'miraculous'),
        'type'    => 'text'
    ),
    'artists_style' => array(
        'label'   => __('Style format', 'miraculous'),
        'type'    => 'select',
        'choices' => array(
            'arstyle1'  => __('Slider', 'miraculous'),
            'arstyle2'  => __('Grid', 'miraculous')
        ),
        'value'   => 'arstyle1'
    ),
    'artists_type' => array(
        'label'   => __('Artist Type', 'miraculous'),
        'type'    => 'select',
        'choices' => $category
    ),
    'artists_number'   => array(
        'label'   => __('Number of Artists', 'miraculous'),
        'help'    => __('help', 'miraculous'),
        'type'    => 'text'
    )
);  
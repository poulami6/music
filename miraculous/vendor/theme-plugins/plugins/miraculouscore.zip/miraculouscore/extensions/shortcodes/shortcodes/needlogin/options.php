<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'need_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
    'need_logoimage'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'upload',
        'images_only' => true,
    ),
	
);
?>
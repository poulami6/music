<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'genre_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
    'number_limits'   => array(
        'label'   => __('Number of genre', 'miraculous'),
        'type'    => 'text'
    ),
);
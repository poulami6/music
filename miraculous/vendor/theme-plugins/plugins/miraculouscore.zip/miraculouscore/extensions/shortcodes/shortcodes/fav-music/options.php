<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'fav_music_label'   => array(
        'label'   => __('Label', 'miraculous'),
        'type'    => 'text'
    ),
    'fav_music_list' => array(
        'label'   => __('List by', 'miraculous'),
        'type'    => 'select',
        'choices' => array(
            'songs'  => __('Songs', 'miraculous'),
            'albums'  => __('Albums', 'miraculous'),
            'artist'  => __('Artists', 'miraculous'),
            'radio'  => __('Radios', 'miraculous')
        ),
        'value'   => 'songs'
    ),
    'fav_music_number' => array(
        'label'   => __('Number of Songs', 'miraculous'),
        'type'    => 'text'
    )
);
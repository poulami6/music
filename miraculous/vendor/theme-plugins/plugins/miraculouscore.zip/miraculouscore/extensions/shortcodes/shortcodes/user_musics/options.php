<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'user_music_label'   => array(
        'label'   => __('Label', 'miraculous'),
        'type'    => 'text'
    ),
    'user_music_type' => array(
        'label'   => __('Tracks', 'miraculous'),
        'type'    => 'select',
        'choices' => array(
            'free'  => __('Free', 'miraculous'),
            'premium'  => __('Premium', 'miraculous'),
        ),
        'value'   => 'free'
    ),
    'user_music_number' => array(
        'label'   => __('Number of Songs', 'miraculous'),
        'type'    => 'text'
    )
);
?>
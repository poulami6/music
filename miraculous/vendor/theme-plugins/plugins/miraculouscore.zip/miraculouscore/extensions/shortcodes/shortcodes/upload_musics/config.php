<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Upload Tracks', 'miraculous'),
        'description'   => __('Upload Tracks', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-cloud-upload',
        'popup_size'    => 'small',
    )
);
?>
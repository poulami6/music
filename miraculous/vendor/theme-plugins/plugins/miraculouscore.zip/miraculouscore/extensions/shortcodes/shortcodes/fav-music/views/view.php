<?php if (!defined('FW')) die('Forbidden');
$fav_label = $mpurl = '';
if(!empty($atts['fav_music_label'])):
 $fav_label = $atts['fav_music_label'];
else:
 $fav_label = esc_html__('Facourites Songs','miraculous');
endif;
$fav_style = '';
if(!empty($atts['fav_music_list'])):
  $fav_style = $atts['fav_music_list']; 
else:
 $fav_style = esc_html__('songs','miraculous');
endif;
$fav_number ='';
if(!empty($atts['fav_music_number'])):
  $fav_number = $atts['fav_music_number'];
else:
  $fav_number =  12; 
endif;

$miraculous_theme_data = '';
if (function_exists('fw_get_db_settings_option')):  
    $miraculous_theme_data = fw_get_db_settings_option();     
endif; 
$currency = '';
if(!empty($miraculous_theme_data['paypal_currency']) && function_exists('miraculous_currency_symbol')):
    $currency = miraculous_currency_symbol( $miraculous_theme_data['paypal_currency'] );
endif;
$close_icone = get_template_directory_uri().'/assets/images/svg/close.svg';
$more_img = get_template_directory_uri().'/assets/images/svg/more.svg';
$play_img = get_template_directory_uri().'/assets/images/svg/play.svg';
$userid = get_current_user_id();
$music_ids = get_user_meta($userid, 'favourites_songs_lists'.$userid, true);
$albums_ids = get_user_meta($userid, 'favourites_albums_lists'.$userid, true);
$artists_ids = get_user_meta($userid, 'favourites_artists_lists'.$userid, true);
$radio_ids = get_user_meta($userid, 'favourites_radios_lists'.$userid, true);

if($userid): 
    if($fav_style == 'songs'):
    if($music_ids):
        $sg_args = array('post_type' => 'ms-music',
                        'posts_per_page' => $fav_number,
                        'post__in' => $music_ids,
                        );
        $music_posts = new WP_Query( $sg_args );
        $list_type = 'music';
            if( $music_posts->have_posts() ): ?>
			<div class="ms_free_download ms_purchase_wrapper">
			<?php if(!empty($fav_label)): ?>
                <div class="ms_heading">
                    <h1><?php echo esc_html($fav_label); ?></h1>
                </div>
			<?php endif; ?>
                <div class="album_inner_list">
                    <div class="album_list_wrapper">
                        <ul class="album_list_name">
                            <li><?php esc_html_e('#','miraculous');?></li>
                            <li><?php esc_html_e('Song Title','miraculous');?></li>
                            <li><?php esc_html_e('Artists','miraculous');?></li>
                            <li class="text-center">
							<?php esc_html_e('price','miraculous');?></li>
                            <li class="text-center">
							<?php esc_html_e('Duration','miraculous');?></li>
                            <li class="text-center">
							<?php esc_html_e('More','miraculous');?></li>
                            <li class="text-center">
							<?php esc_html_e('remove','miraculous');?></li>
                        </ul>
                        <?php 
						$i=1; 
						while ( $music_posts->have_posts() ) : $music_posts->the_post(); 
						$attach_meta = array();
                    	$music_extranal_url = get_post_meta(get_the_id(), 'fw_option:music_extranal_url', true);
                        if(!empty($music_extranal_url)):
                            $mpurl = $music_extranal_url;
                        else:
                            $mpurl = get_post_meta(get_the_id(), 'fw_option:mp3_full_songs', true);
                        endif;
                    	if($mpurl) {
                    		$attach_meta = wp_get_attachment_metadata( $mpurl['attachment_id'] );
                    	}
                    	$image_uri = get_the_post_thumbnail_url ( get_the_id() );
						?>
                        <ul class="ms_list_songs">
                                <li><a href="javascript:;">
								<span class="play_no">
								<?php echo (strlen($i) < 2) ? '0'.$i : $i; ?></span>
								<span class="play_hover"></span></a></li>
                                <li><a href="javascript:;" data-musicid="<?php echo esc_attr(get_the_id()); ?>" class="play_single_music"><?php the_title(); ?></a></li>
                                <?php
								$artists_name = array();
								$music_price = '';
                                if(function_exists('fw_get_db_post_option')){
                                    $artists_ids = fw_get_db_post_option(get_the_id(), 'music_artists'); 
                                    if(!empty($artists_ids)){
                                        foreach($artists_ids as $artists_id) {
                                            $artists_name[] = get_the_title($artists_id);
                                        } 
                                    }
                                    $music_price_arr = fw_get_db_post_option(get_the_id(), 'music_type_options');
                                    if( !empty( $music_price_arr['premium']['single_music_price'] ) ){
                                        $music_price = $music_price_arr['premium']['single_music_price'];
                                    }
                                }
								
								?>
                                <li><a href="javascript:;" class="play_single_music"><?php echo implode(', ', $artists_name); ?></a></li>
                                <?php if($music_price == ''): ?>
                                    <li class="text-center"><a href="javascript:;"><?php esc_html_e('Free', 'miraculous'); ?></a></li>
                                <?php else: ?>
                                    <li class="text-center"><a href="javascript:;"><?php printf( __('%s%s', 'miraculous'), $currency, $music_price ); ?></a></li>
                                <?php endif; ?>
                                <li class="text-center">
								 <a href="javascript:;">
								 <?php 
								 echo (isset($attach_meta['length_formatted'])) ? $attach_meta['length_formatted'] : "0.00"; 
								 ?></a></li>
                                <li class="text-center ms_more_icon">
								   <a href="javascript:;">
								   <span class="ms_icon1 ms_active_icon"></span></a>
                                    <ul class="more_option">
                                        <li>
											<a href="javascript:;" class="add_to_queue" data-musicid="<?php esc_html_e(get_the_id()); ?>" data-musictype="<?php esc_attr_e($list_type); ?>">
											<span class="opt_icon">
											  <span class="icon icon_queue"></span></span>
											   <?php 
											   echo esc_html__('Add To Queue', 'miraculous'); ?>
											</a>
										</li>
                                        <li>
											<a href="javascript:;" class="ms_download" data-msmusic="<?php echo esc_attr(get_the_id()); ?>">
											<span class="opt_icon">
											<span class="icon icon_dwn"></span>
											</span>
											<?php echo esc_html__('Download Now', 'miraculous'); ?></a>
										</li>
                                        <li>
											<a href="javascript:;" class="ms_add_playlist" data-msmusic="<?php echo esc_attr(get_the_id()); ?>">
											<span class="opt_icon">
											  <span class="icon icon_playlst"></span>
											</span>
											<?php 
											 echo esc_html__('Add To Playlist', 'miraculous'); ?> 
											</a>
										</li>
                                        <li>
											<a href="javascript:;" class="ms_share_music" data-shareuri="<?php esc_attr_e(get_the_permalink()); ?>" data-sharename="<?php the_title_attribute(); ?>">
											<span class="opt_icon">
											  <span class="icon icon_share"></span>
											</span>
											  <?php echo esc_html__('Share', 'miraculous'); ?>
											</a>
										</li>
                                    </ul>
                                </li>
                                <li class="text-center">
									<a href="javascript:;" class="remove_favourite_music" musicid="<?php echo esc_attr(get_the_id()); ?>">
									<?php if(!empty($close_icone)): ?>
										 <span class="ms_close">
											<img src="<?php echo esc_url($close_icone); ?>" alt="<?php echo esc_html__('close icone','miraculous'); ?>">
										 </span>
									<?php endif; ?>	 
									</a>
								</li>
                            </ul>
                        <?php $i++; endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    </div>
                </div>
            </div>
       <?php 
	         endif;
           endif;
        endif;
        if($fav_style == 'albums'):
		    if($albums_ids):
			$sg_args = array('post_type' => 'ms-albums',
							'posts_per_page' => $fav_number,
							'post__in' => $albums_ids,
							);
        $album_posts = new WP_Query( $sg_args );
        if($album_posts->have_posts() ): 
            $musictype = 'album';
        ?>
        <div class="ms_fea_album_slider">
		<?php if(!empty($fav_label)): ?>
            <div class="ms_heading">
                <h1><?php echo esc_html( $fav_label ); ?></h1>
                <span class="veiw_all">
				</span>
            </div>
		<?php endif; ?>
                <div class="ms_relative_inner">
                    <div class="ms_feature_slider swiper-container swiper-container-horizontal">
                        <div class="swiper-wrapper">
                         <?php
							$i=0; 
							while ( $album_posts->have_posts() ) : $album_posts->the_post(); ?>
							<div class="swiper-slide<?php echo ($i==0) ? ' swiper-slide-active' : '';?>" data-swiper-slide-index="<?php echo _e($i); ?>">
                                    <div class="ms_rcnt_box">
                                        <div class="ms_rcnt_box_img">
                                            <?php the_post_thumbnail( 'large' ); ?>
                                            <div class="ms_main_overlay">
											<?php if(!empty($more_img)): ?>
                                                <div class="ms_box_overlay"></div>
                                                <div class="ms_more_icon">
                                                    <img src="<?php echo esc_url($more_img); ?>" alt="<?php echo esc_attr__('more image','miraculous'); ?>">
                                                </div>
											<?php endif; ?>
                                                <ul class="more_option">
                                                    <li>
													  <a href="javascript:;" class="add_to_queue" data-musicid="<?php esc_html_e(get_the_id()); ?>" data-musictype="<?php esc_html_e($musictype); ?>">
														<span class="opt_icon">
														<span class="icon icon_queue"></span>
														</span><?php esc_html_e('Add To Queue','miraculous'); ?>
													  </a>
													</li>
                                                    <li>
													  <a href="javascript:;" class="ms_share_music" data-shareuri="<?php esc_attr_e(get_the_permalink()); ?>" data-sharename="<?php the_title_attribute(); ?>">
														<span class="opt_icon">
														<span class="icon icon_share"></span>
														</span>
														<?php esc_html_e('Share','miraculous'); ?>
													  </a>
													</li>
                                                </ul>
												<?php if(!empty($play_img)): ?>
                                                <div class="ms_play_icon play_btn play_music" data-musicid="<?php esc_html_e(get_the_id()); ?>" data-musictype="<?php esc_html_e($musictype); ?>">
                                        <img src="<?php echo esc_url($play_img); ?>" alt="<?php echo esc_attr__('play icone','miraculous'); ?>">
                                                </div>
												<?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="ms_rcnt_box_text">
                                            <h3>
											<a href="<?php echo esc_url(get_the_permalink()); ?>">
											<?php the_title(); ?>
											</a>
											</h3>
                                            <?php 
											$artists_name = array();
                                            if(function_exists('fw_get_db_post_option')){
                                                $artists_ids = fw_get_db_post_option(get_the_id(), 'album_artists'); 
                                                if(!empty($artists_ids)){
                                                    foreach($artists_ids as $artists_id) {
                                                        $artists_name[] = get_the_title($artists_id);
                                                    } 
                                                }
                                            }
											?>
                                            <p>
											<?php echo implode(', ', $artists_name); ?></p>
                                        </div>
                                    </div>
                                </div>
                             <?php 
							 $i++; 
							 endwhile; 
                             wp_reset_postdata();
							?>
                        </div>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                     </div>
                    <div class="swiper-button-next1 slider_nav_next" tabindex="0" role="button" aria-label="<?php esc_attr_e('Next slide','miraculous'); ?>"></div>
                    <div class="swiper-button-prev1 slider_nav_prev" tabindex="0" role="button" aria-label="<?php esc_attr_e('Previous slide','miraculous'); ?>"></div>
                </div>
            </div>
        <?php endif;
          endif;
        endif;
        if( $fav_style == 'artist' ):
			if($artists_ids):
                $sg_args = array('post_type' => 'ms-artists',
								 'posts_per_page' => $fav_number,
								 'post__in' => $artists_ids,
								);
        $artist_posts = new WP_Query( $sg_args );
        if( $artist_posts->have_posts() ): 
            $musictype = 'artist';
        ?>
        <div class="ms_featured_slider">
                <div class="ms_heading">
                    <h1><?php echo esc_html( $fav_label ); ?></h1>
                </div>
                <div class="ms_relative_inner">
                    <div class="ms_feature_slider swiper-container swiper-container-horizontal">
                        <div class="swiper-wrapper">
                            <?php
							$i=0; 
							while ( $artist_posts->have_posts() ) : $artist_posts->the_post(); ?>
                            <div class="swiper-slide<?php echo ($i==0) ? ' swiper-slide-active' : '';?>" data-swiper-slide-index="<?php echo _e($i); ?>">
                                    <div class="ms_rcnt_box">
                                        <div class="ms_rcnt_box_img">
                                            <?php the_post_thumbnail( 'large' ); ?>
                                            <div class="ms_main_overlay">
                                                <div class="ms_box_overlay"></div>
                                                <div class="ms_more_icon">
                                                    <img src="<?php echo esc_url($more_img) ?>" alt="<?php esc_html_e('More', 'miraculous') ?>">
                                                </div>
                                                <ul class="more_option">
                                                    <li>
														<a href="javascript:;" class="add_to_queue" data-musicid="<?php esc_html_e(get_the_id()); ?>" data-musictype="<?php esc_html_e($musictype); ?>">
														<span class="opt_icon">
														<span class="icon icon_queue"></span>
														</span><?php 
														 esc_html_e('Add To Queue','miraculous'); ?>
														 </a>
													</li>
                                                    <li>
													<a href="javascript:;" class="ms_share_music" data-shareuri="<?php esc_attr_e(get_the_permalink()); ?>" data-sharename="<?php the_title_attribute(); ?>"><span class="opt_icon"><span class="icon icon_share"></span>
													</span><?php 
													 esc_html_e('Share','miraculous'); ?></a>
													</li>
                                                </ul>
												<?php if(!empty($play_img)): ?>
                                                <div class="ms_play_icon play_btn play_music" data-musicid="<?php esc_html_e(get_the_id()); ?>" data-musictype="<?php esc_html_e($musictype); ?>"><img src="<?php echo esc_url($play_img); ?>" alt="<?php echo esc_attr__('play icone','miraculous'); ?>">
                                                </div>
												<?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="ms_rcnt_box_text">
                                            <h3><a href="<?php echo esc_url(get_the_permalink(get_the_ID())); ?>"><?php the_title(); ?></a></h3>
                                        </div>
                                    </div>
                                </div>
                            <?php 
							$i++; 
							endwhile; 
                            wp_reset_postdata();
							?>
                        </div>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                      </div>
                      <div class="swiper-button-next1 slider_nav_next" tabindex="0" role="button" aria-label="<?php esc_attr_e('Next slide','miraculous'); ?>"></div>
                      <div class="swiper-button-prev1 slider_nav_prev" tabindex="0" role="button" aria-label="<?php esc_attr_e('Previous slide','miraculous'); ?>"></div>
                </div> 
            </div>
        <?php endif;
         endif;
      endif;

if($fav_style == 'radio'):
            if($radio_ids):
            $sg_args = array('post_type' => 'ms-radios',
                            'posts_per_page' => $fav_number,
                            'post__in' => $radio_ids,
                            );
        $radio_posts = new WP_Query( $sg_args );
        if($radio_posts->have_posts() ): 
            $musictype = 'radio';
        ?>
        <div class="ms_fea_album_slider">
        <?php if(!empty($fav_label)): ?>
            <div class="ms_heading">
                <h1><?php echo esc_html( $fav_label ); ?></h1>
                <span class="veiw_all">
                </span>
            </div>
        <?php endif; ?>
                <div class="ms_relative_inner">
                    <div class="ms_feature_slider swiper-container swiper-container-horizontal">
                        <div class="swiper-wrapper">
                         <?php
                            $i=0; 
                            while ( $radio_posts->have_posts() ) : $radio_posts->the_post(); ?>
                            <div class="swiper-slide<?php echo ($i==0) ? ' swiper-slide-active' : '';?>" data-swiper-slide-index="<?php echo _e($i); ?>">
                                    <div class="ms_rcnt_box">
                                        <div class="ms_rcnt_box_img">
                                            <?php the_post_thumbnail( 'large' ); ?>
                                            <div class="ms_main_overlay">
                                            <?php if(!empty($more_img)): ?>
                                                <div class="ms_box_overlay"></div>
                                                <div class="ms_more_icon">
                                                    <img src="<?php echo esc_url($more_img); ?>" alt="<?php echo esc_attr('more image','miraculous'); ?>">
                                                </div>
                                            <?php endif; ?>
                                                <ul class="more_option">
                                                    <li>
                                                      <a href="javascript:;" class="ms_share_music" data-shareuri="<?php esc_attr_e(get_the_permalink()); ?>" data-sharename="<?php the_title_attribute(); ?>">
                                                        <span class="opt_icon">
                                                        <span class="icon icon_share"></span>
                                                        </span>
                                                        <?php esc_html_e('Share','miraculous'); ?>
                                                      </a>
                                                    </li>
                                                </ul>
                                                <?php if(!empty($play_img)): ?>
                                                <div class="ms_play_icon play_btn play_music" data-musicid="<?php esc_html_e(get_the_id()); ?>" data-musictype="<?php esc_html_e($musictype); ?>">
                                                    <img src="<?php echo esc_url($play_img); ?>" alt="<?php echo esc_attr__('play icone','miraculous'); ?>">
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="ms_rcnt_box_text">
                                            <h3>
                                            <a href="<?php echo esc_url(get_the_permalink()); ?>">
                                            <?php the_title(); ?>
                                            </a>
                                            </h3>
                                            <?php 
                                            $artists_name = array();
                                            if(function_exists('fw_get_db_post_option')){
                                                $artists_ids = fw_get_db_post_option(get_the_id(), 'radio_artists'); 
                                                if(!empty($artists_ids)){
                                                    foreach($artists_ids as $artists_id) {
                                                        $artists_name[] = get_the_title($artists_id);
                                                    } 
                                                }
                                            }
                                            ?>
                                            <p>
                                            <?php echo implode(', ', $artists_name); ?></p>
                                        </div>
                                    </div>
                                </div>
                             <?php 
                             $i++; 
                             endwhile; 
                             wp_reset_postdata();
                            ?>
                        </div>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                     </div>
                    <div class="swiper-button-next1 slider_nav_next" tabindex="0" role="button" aria-label="<?php esc_attr_e('Next slide','miraculous'); ?>"></div>
                    <div class="swiper-button-prev1 slider_nav_prev" tabindex="0" role="button" aria-label="<?php esc_attr_e('Previous slide','miraculous'); ?>"></div>
                </div>
            </div>
        <?php endif;
          endif;
        endif;
    
else: ?>
<script>
    $(document).ready(function(){
       $("#myModal1").modal("show");
    });
</script>
<?php endif;


<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Need To Login', 'miraculous'),
        'description'   => __('Add Need Login Section', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-building-o',
        'popup_size'    => 'small', 
    )
);
?>
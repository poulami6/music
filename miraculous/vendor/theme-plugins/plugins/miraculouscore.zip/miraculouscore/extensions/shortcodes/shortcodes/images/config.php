<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title'         => __('Images', 'miraculous'),
        'description'   => __('Images', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-picture-o',
        'popup_size'    => 'small',
    )
);
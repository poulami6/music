<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['id'] = 'miraculousid';

$manifest['supported_extensions'] = array(	
    'page-builder' => array(),
	'breadcrumbs' => array(),
	'backups' => array(),
);  
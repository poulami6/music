<?php if (!defined('FW')) die('Forbidden');
/**
 * Theme config 
 *
 * @var array $cfg Fill this array with configuration data
 */

$cfg = array(
    // Theme Settings form ajax submit
    'settings_form_ajax_submit' => true,
    // Theme Settings side tabs
    'settings_form_side_tabs' => true,
);